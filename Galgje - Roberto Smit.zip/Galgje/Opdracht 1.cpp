#pragma hdrstop
#pragma argsused

// #include <stdio.h>
#include <iostream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <time.h>
#include <cctype>

using namespace std;

//Variabelen
string zoekwoord = "";
string display;
string woordenlijst[5] = {"patat", "papier", "auto", "parachute", "friesepoort"};
string speler1, speler2;
string currentSpeler;

int beurten = 9, x, lengtewoord;

//Functies
void keuzeMenu();
void keuzeMenu2();
void verwerkWoord();
void spelersNamen();
void startSpel();
void showSpel();
void beginSpel(char* pzoekwoord);
void speler_vs_speler();
void speler_vs_cpu();
void endGame(string display, string zoekwoord);
void opnieuwSpelen();

int main()
{
	keuzeMenu();

	system("pause >> null");
	return 0;
}

void keuzeMenu() {
	//Keuzemenu
	cout << "Galgje\n"
		 << "=-=-=-=-=\n\n"
		 << "Wil je met zijn tweeen spelen of tegen de CPU?\n\n"
		 << "1| speler vs speler\n"
		 << "2| speler vs cpu\n\n"
		 << "Type 1 of 2 in\n\n"
		 << "Keuze: ";
	cin >> x;

	if (x == 1) {
		speler_vs_speler();
	}
	else if (x == 2) {
		speler_vs_cpu();
	}
	else {
		keuzeMenu();
	}
	system("cls");
}



void spelersNamen(){
  //Speler namen
  if(x == 1){

  cout << "Wie wordt speler 1?\n"
	   << "Speler 1: ";
  cin >> speler1;

  cout << "Wie wordt speler 2?\n"
	   << "Speler 2: ";
  cin >> speler2;

  system ("cls");

  }
  else if(x == 2){
  cout << "Welcome speler wat is je naam? \n"
	   << "Speler: ";
  cin >> currentSpeler;

  system("cls");
  }
}

void verwerkWoord(){
string woord;
int keuze;
//Woord noemen
if(x == 1) {
	cout << "Wie gaat een woord verzinnen?\n"
		 << "1| " + speler1 << endl;
	cout << "2| " + speler2 << endl;
	cin >> keuze;

	if(keuze == 1) {
		currentSpeler = speler1;
	}
	else if(keuze == 2) {
		currentSpeler = speler2;
	}
	else {
		verwerkWoord();
	}
	system("cls");

	cout << "Wat is je woord, " + currentSpeler + "?\n"
		 << "Woord: ";
	cin >> woord;
	system("cls");
	zoekwoord = woord;
	lengtewoord = woord.length();

	char arrzoekwoord[zoekwoord.length() + 1];
	strcpy(arrzoekwoord, zoekwoord.c_str());
	char* pzoekwoord = arrzoekwoord;
}
else if(x == 2) {
	srand(time(0));
	zoekwoord = woordenlijst[rand() % 5];
}
	lengtewoord = zoekwoord.length();
	char arrzoekwoord[lengtewoord + 1];
	strcpy(arrzoekwoord, zoekwoord.c_str());
	char* pzoekwoord = arrzoekwoord;

	beginSpel(pzoekwoord);
}


void startSpel(char* pzoekwoord){
	char start{};
	if(x == 1){
		std::cout << "Galgje\n"
		 << "_______________\n"
		 << "|       }      \n"
		 << "|       0      \n"
		 << "|       |      \n"
		 << "|     / | \\   \n"
		 << "|    /  |  \\  \n"
		 << "|      / \\    \n"
		 << "|     /   \\   \n"
		 << "|              \n"
		 << "|              \n\n"
		 << "---------------\n"
		 << "Tik een toets in (en klik daarna op enter) om te beginnen." << endl;
		cin >> start;
		system("cls");
		cout << "Galgje\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n\n"
		 << "---------------"<< endl;
		beginSpel(pzoekwoord);
	}
	else if(x == 2){
		cout << "Galgje\n"
		 << "_______________\n"
		 << "|       }      \n"
		 << "|       0      \n"
		 << "|       |      \n"
		 << "|     / | \\   \n"
		 << "|    /  |  \\  \n"
		 << "|      / \\    \n"
		 << "|     /   \\   \n"
		 << "|              \n"
		 << "|              \n\n"
		 << "---------------\n"
		 << "De computer genereerd een woord voor je.\n"
		 << "Klik op een toets om te beginnen..." << endl;
		 cin >> start;
		 system("cls");
		 beginSpel(pzoekwoord);

	}
}

void showSpel(){
	switch (beurten) {
		case 9:
			{
		 std::cout << "Galgje\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "---------------"<< endl;
			break;
			}
		case 8:
			{
			std::cout
			 << "_______________\n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "---------------" << endl;
				break;
			}
		case 7:
			{
			std::cout
			 << "_______________\n"
			 << "|//             \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "---------------" << endl;
				break;
			}
		case 6:
			{
			std::cout
			 << "_______________\n"
			 << "|//     }      \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "---------------" << endl;
				break;
			}
		case 5:
			{
			std::cout
			 << "_______________\n"
			 << "|//     }      \n"
			 << "|       0      \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "---------------" << endl;
				break;
			}
		case 4:
			{
			std::cout
			 << "_______________\n"
			 << "|//     }      \n"
			 << "|       0      \n"
			 << "|       |      \n"
			 << "|       |      \n"
			 << "|       |      \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "---------------" << endl;
				break;
			}
		case 3:
			{
			std::cout
			 << "_______________\n"
			 << "|//     }      \n"
			 << "|       0      \n"
			 << "|       |      \n"
			 << "|     / |      \n"
			 << "|    /  |      \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "|              \n"
			 << "---------------" << endl;
				break;
			}
		case 2:
			{
			std::cout
			 << "_______________\n"
			 << "|//     }      \n"
			 << "|       0      \n"
			 << "|       |      \n"
			 << "|     / |      \n"
			 << "|    /  |      \n"
			 << "|      /       \n"
			 << "|     /        \n"
			 << "|              \n"
			 << "|              \n"
			 << "---------------" << endl;
				break;
			}
		case 1:
			{
			std::cout
			 << "_______________\n"
			 << "|//     }      \n"
			 << "|       0      \n"
			 << "|       |      \n"
			 << "|      /|\\   \n"
			 << "|     / | \\  \n"
			 << "|      /       \n"
			 << "|     /        \n"
			 << "|              \n"
			 << "|              \n"
			 << "---------------" << endl;
				break;
			}
		case 0:
			{
			 std::cout
			 << "_______________\n"
			 << "|//     }      \n"
			 << "|       0      \n"
			 << "|       |      \n"
			 << "|      /|\\    \n"
			 << "|     / | \\   \n"
			 << "|      / \\    \n"
			 << "|     /   \\   \n"
			 << "|              \n"
			 << "|              \n"
			 << "---------------" << endl;
			 break;
			}
		default: {
		cout << "FOUTMELDING!\n"
			 << "---------------" << endl;
		endGame(display, zoekwoord);
		break;
		}

	}
}

void beginSpel(char* pzoekwoord){
//Spel begint hier onder.
	cout << "Galgje\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "|\n"
		 << "---------------\n"<< endl;

if (beurten > 0) {
	display = pzoekwoord;
	for(int i = 0; i < lengtewoord; i++){
	display[i] = '.';
	}

	for(int i = 0; i < display.length(); i++){
	while(1) {
		cout << display << ": ";
		char response;
		cin >> response;

		bool goodGuess = false;
		for (int i = 0; i < lengtewoord; i++)
			if (response == pzoekwoord[i]) {
				system("cls");
				display[i] = pzoekwoord[i];
				goodGuess = true;
				showSpel();
				if(display == pzoekwoord){
					endGame(display, pzoekwoord);
				}
			}
			if (!goodGuess) {
				beurten--;
				cout << response << " is niet in het woord." << endl;
				system("cls");
				showSpel();
			}
		}

	}
}
}

void speler_vs_speler(){
	//Spel speler tegen speler
	spelersNamen();
	verwerkWoord();
	showSpel();
}

void speler_vs_cpu(){
	//Spel speler tegen computer
	spelersNamen();
	verwerkWoord();
	showSpel();
}
void endGame(string display, string zoekwoord) {

	if (display == zoekwoord) {
		cout << "Gefeliciteerd! " + currentSpeler + ". Je hebt het woord geraden!\n"
			 << "Het woord was: " << zoekwoord << endl << endl;
		cout << "Klik op enter om verder te gaan..." << endl;
		cin.get();
		system("cls");
	}
	else {
		cout << "Helaas " + currentSpeler + ", je hebt het woord niet geraden!\n" << endl;
		cout << "Klik op enter om verder te gaan..." << endl;
		cin.get();
		system("cls");
	}

	 opnieuwSpelen();
}

void opnieuwSpelen() {
	string keuze;

	cout << "-----------------------\n"
		 << "Opnieuw spelen?\n\n"
		 << "Type (ja of nee)\n"
		 <<	"Keuze: ";
	cin >> keuze;

	if (keuze == "ja" || keuze == "Ja") {
	  system("cls");
	  zoekwoord = "";
	  beurten = 9;
	  main();
	}
	else if (keuze == "nee" || keuze == "Nee") {
	  cout << "Bedankt voor het spelen!" << endl;
	  system("pause >> null");
	  exit(0);
	}
	else {
	system("cls");
		opnieuwSpelen();
	}
   }
